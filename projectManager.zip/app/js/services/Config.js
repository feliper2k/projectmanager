function ConfigService() {
    const config = {

    };

    return config;
}

export default {
    name: 'ConfigService',
    fn: ConfigService
};
